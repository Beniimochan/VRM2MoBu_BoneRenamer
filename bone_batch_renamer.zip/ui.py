# -*- coding: utf-8 -*-
"""
Bone Batch Renamer - UI定義モジュール
3Dビューポートのサイドバー（Nパネル）に表示するUIListおよびメインパネルを定義します。
"""

import bpy
from bpy.types import Panel, UIList


class BONE_UL_mapping_list(UIList):
    """ボーン名マッピングを表示・編集するためのカスタムUIList"""

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # 行の分割レイアウト（有効フラグ、変更前、矢印、変更後）
        row = layout.row(align=True)

        # 有効/無効チェックボックス
        row.prop(item, "is_enabled", text="")

        # 変更前ボーン名
        sub_from = row.split(factor=0.48, align=True)
        sub_from.prop(item, "from_name", text="", emboss=True, icon='BONE_DATA')

        # 中央の矢印
        sub_arrow = sub_from.split(factor=0.08, align=True)
        sub_arrow.label(icon='RIGHTARROW')

        # 変更後ボーン名
        sub_arrow.prop(item, "to_name", text="", emboss=True)

    def draw_filter(self, context, layout):
        """UIList標準の検索・フィルタボックス"""
        pass


class BONE_PT_batch_rename_panel(Panel):
    """3Dビューポートのサイドバーに表示するメインコントロールパネル"""
    bl_label = "ボーン一括リネーム"
    bl_idname = "BONE_PT_batch_rename"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Bone Renamer'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.bone_batch_rename_settings

        # 1. アーマチュア選択セクション
        box_armature = layout.box()
        col = box_armature.column(align=True)
        col.label(text="対象モデル / アーマチュア:", icon='ARMATURE_DATA')
        col.prop(settings, "target_armature", text="")

        # アクティブオブジェクトの判定と状態表示
        active_obj = context.active_object
        target = settings.target_armature or (active_obj if active_obj and active_obj.type == 'ARMATURE' else None)

        if not target:
            col.label(text="※ 3Dビューでアーマチュアを選択してください", icon='INFO')
        else:
            row = col.row(align=True)
            row.label(text=f"選択中: {target.name}", icon='CHECKMARK')

        # 2. ボーン一括取得ボタン
        row = box_armature.row(align=True)
        op_pop = row.operator("bone.populate_bones", text="現在のボーンを読み込む", icon='IMPORT')
        op_pop.clear_existing = True
        op_pop.selected_only = False

        # 3. マッピングリストセクション
        layout.label(text=f"リネーム対応リスト ({len(settings.items)} 件):", icon='LINENUMBERS_ON')
        
        row_list = layout.row()
        row_list.template_list(
            "BONE_UL_mapping_list",
            "",
            settings,
            "items",
            settings,
            "active_index",
            rows=6,
        )

        # リスト右横の操作ボタン（追加、削除、上下、クリア）
        col_ops = row_list.column(align=True)
        col_ops.operator("bone.mapping_add", text="", icon='ADD')
        col_ops.operator("bone.mapping_remove", text="", icon='REMOVE')
        col_ops.separator()
        col_ops.operator("bone.mapping_swap", text="", icon='ARROW_LEFTRIGHT')
        col_ops.separator()
        col_ops.operator("bone.mapping_clear", text="", icon='TRASH')

        # 4. CSVインポート・エクスポート
        box_csv = layout.box()
        box_csv.label(text="CSV 連携:", icon='FILE_TEXT')
        row_csv = box_csv.row(align=True)
        row_csv.operator("bone.import_csv", text="CSV読込", icon='FILE_FOLDER')
        row_csv.operator("bone.export_csv", text="CSV保存", icon='EXPORT')
        box_csv.prop(settings, "csv_has_header", text="1行目をヘッダーとしてスキップ")

        # 5. リネーム詳細オプション
        box_opt = layout.box()
        box_opt.label(text="リネーム設定オプション:", icon='PREFERENCES')
        box_opt.prop(settings, "match_mode", text="検索方式")
        box_opt.prop(settings, "case_sensitive")
        box_opt.prop(settings, "sync_vertex_groups")
        box_opt.prop(settings, "sync_animations")

        # 6. 一括リネーム実行ボタン（大きめ）
        layout.separator()
        col_exec = layout.column(align=True)
        col_exec.scale_y = 1.6
        col_exec.operator("bone.batch_rename", text="一括リネームを実行", icon='FILE_REFRESH')


classes = (
    BONE_UL_mapping_list,
    BONE_PT_batch_rename_panel,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
