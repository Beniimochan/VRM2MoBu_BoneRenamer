# -*- coding: utf-8 -*-
"""
Bone Batch Renamer - オペレーター定義モジュール
リネーム実行、ボーン自動抽出、CSV入出力、リスト操作などのオペレーターを定義します。
"""

import os
import csv
import re
import uuid
import bpy
from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper, ExportHelper
from bpy.props import StringProperty, BoolProperty, EnumProperty


def get_target_armature(context, settings):
    """リネーム対象のアーマチュアオブジェクトを取得するヘルパー関数"""
    if settings.target_armature and settings.target_armature.type == 'ARMATURE':
        return settings.target_armature
    
    # アクティブオブジェクトがアーマチュアの場合
    if context.active_object and context.active_object.type == 'ARMATURE':
        return context.active_object
    
    # 選択オブジェクトの中からアーマチュアを検索
    for obj in context.selected_objects:
        if obj.type == 'ARMATURE':
            return obj
            
    return None


def get_related_meshes(armature_obj):
    """指定されたアーマチュアに関連付けられている（変形対象の）メッシュオブジェクト群を取得"""
    related_meshes = set()
    
    for obj in bpy.data.objects:
        if obj.type != 'MESH':
            continue
        
        # 1. 親がアーマチュア
        if obj.parent == armature_obj:
            related_meshes.add(obj)
            continue
            
        # 2. アーマチュアモディファイアで参照されている
        for mod in obj.modifiers:
            if mod.type == 'ARMATURE' and mod.object == armature_obj:
                related_meshes.add(obj)
                break
                
    return related_meshes


class BONE_OT_batch_rename(Operator):
    """設定されたマッピングリストに従ってボーンを一括リネームします"""
    bl_idname = "bone.batch_rename"
    bl_label = "一括リネーム実行"
    bl_description = "リストの設定に従ってアーマチュアのボーン名を一括変更します"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.bone_batch_rename_settings
        armature_obj = get_target_armature(context, settings)

        if not armature_obj:
            self.report({'ERROR'}, "対象のアーマチュアオブジェクトが見つかりません。3Dビューで選択するか設定してください")
            return {'CANCELLED'}

        # 有効なマッピングの抽出
        valid_mappings = []
        for item in settings.items:
            if item.is_enabled and item.from_name:
                valid_mappings.append((item.from_name, item.to_name))

        if not valid_mappings:
            self.report({'WARNING'}, "有効なリネーム設定（変更前ボーン名）がありません")
            return {'CANCELLED'}

        armature_data = armature_obj.data
        all_bones = armature_data.bones

        # モードの保存（安全なリネームのため一時的にObjectまたはPoseモードへ）
        original_mode = armature_obj.mode
        if original_mode == 'EDIT':
            bpy.ops.object.mode_set(mode='OBJECT')

        renamed_count = 0
        rename_pairs = []  # (bone_obj, old_name, new_name)

        # 1. リネーム対象の特定と計画
        if settings.match_mode == 'EXACT':
            # 完全一致モード
            for from_name, to_name in valid_mappings:
                if not to_name:
                    continue  # 変更後が空の場合はスキップ
                
                # 大文字・小文字の区別
                target_bone = None
                if settings.case_sensitive:
                    target_bone = all_bones.get(from_name)
                else:
                    for b in all_bones:
                        if b.name.lower() == from_name.lower():
                            target_bone = b
                            break

                if target_bone and target_bone.name != to_name:
                    rename_pairs.append((target_bone, target_bone.name, to_name))

        else:
            # 部分置換モード (PARTIAL)
            flags = 0 if settings.case_sensitive else re.IGNORECASE
            for bone in all_bones:
                cur_name = bone.name
                new_name = cur_name
                for from_str, to_str in valid_mappings:
                    if not from_str:
                        continue
                    if settings.case_sensitive:
                        new_name = new_name.replace(from_str, to_str)
                    else:
                        pattern = re.compile(re.escape(from_str), flags)
                        new_name = pattern.sub(to_str, new_name)

                if new_name != cur_name and new_name:
                    rename_pairs.append((bone, cur_name, new_name))

        if not rename_pairs:
            # 元のモードに戻す
            if armature_obj.mode != original_mode:
                bpy.ops.object.mode_set(mode=original_mode)
            self.report({'INFO'}, "一致するボーンが見つからなかったため、変更はありませんでした")
            return {'FINISHED'}

        # 2. 衝突防止のための2段階リネーム (Swap / Chain rename対応)
        # 第1段階: 一時的な一意の名前にリネーム
        temp_renames = []
        token = uuid.uuid4().hex[:8]
        for idx, (bone, old_name, new_name) in enumerate(rename_pairs):
            temp_name = f"__TMP_RENAME_{token}_{idx}__"
            bone.name = temp_name
            temp_renames.append((bone, old_name, new_name))

        # 第2段階: 目的の新名前にリネーム
        final_history = []
        for bone, old_name, new_name in temp_renames:
            bone.name = new_name
            final_history.append((old_name, bone.name))
            renamed_count += 1

        # 3. 関連メッシュの頂点グループ同期
        vg_renamed_count = 0
        if settings.sync_vertex_groups:
            related_meshes = get_related_meshes(armature_obj)
            for mesh_obj in related_meshes:
                for old_name, actual_new_name in final_history:
                    vg = mesh_obj.vertex_groups.get(old_name)
                    if vg:
                        vg.name = actual_new_name
                        vg_renamed_count += 1

        # 4. アニメーション（F-Curveデータパス）の同期
        fcurve_updated_count = 0
        if settings.sync_animations:
            for action in bpy.data.actions:
                for fcurve in action.fcurves:
                    for old_name, actual_new_name in final_history:
                        old_path_fragment = f'pose.bones["{old_name}"]'
                        if old_path_fragment in fcurve.data_path:
                            new_path_fragment = f'pose.bones["{actual_new_name}"]'
                            fcurve.data_path = fcurve.data_path.replace(old_path_fragment, new_path_fragment)
                            fcurve_updated_count += 1

        # 元のモードに復帰
        if armature_obj.mode != original_mode:
            bpy.ops.object.mode_set(mode=original_mode)

        report_msg = f"{renamed_count} 個のボーンをリネームしました"
        if settings.sync_vertex_groups and vg_renamed_count > 0:
            report_msg += f"（頂点グループ {vg_renamed_count} 件同期）"
        if settings.sync_animations and fcurve_updated_count > 0:
            report_msg += f"（F-Curve {fcurve_updated_count} 件同期）"

        self.report({'INFO'}, report_msg)
        return {'FINISHED'}


class BONE_OT_populate_bones(Operator):
    """アーマチュアの既存ボーン一覧をマッピングリストに一括ロードします"""
    bl_idname = "bone.populate_bones"
    bl_label = "ボーン一覧を自動取得"
    bl_description = "対象アーマチュアの全ボーン名をマッピングリストに読み込みます"
    bl_options = {'REGISTER', 'UNDO'}

    clear_existing: BoolProperty(
        name="既存リストをクリア",
        description="読み込み前に現在のリストを全削除します",
        default=True,
    )

    selected_only: BoolProperty(
        name="選択中のボーンのみ",
        description="現在選択されているボーンのみを対象にします",
        default=False,
    )

    def execute(self, context):
        settings = context.scene.bone_batch_rename_settings
        armature_obj = get_target_armature(context, settings)

        if not armature_obj:
            self.report({'ERROR'}, "対象のアーマチュアオブジェクトが見つかりません")
            return {'CANCELLED'}

        if self.clear_existing:
            settings.items.clear()

        # 登録済みの名前セット（重複防止用）
        existing_from = {item.from_name for item in settings.items}

        bones_to_add = []
        if self.selected_only and context.selected_pose_bones:
            bones_to_add = [pb.bone for pb in context.selected_pose_bones]
        elif self.selected_only and context.selected_bones:
            bones_to_add = context.selected_bones
        else:
            bones_to_add = armature_obj.data.bones

        added_count = 0
        for b in bones_to_add:
            if b.name not in existing_from:
                item = settings.items.add()
                item.from_name = b.name
                item.to_name = b.name  # 初期値として同名を設定
                item.is_enabled = True
                existing_from.add(b.name)
                added_count += 1

        self.report({'INFO'}, f"{added_count} 個のボーンをリストに追加しました")
        return {'FINISHED'}


class BONE_OT_add_item(Operator):
    """マッピングリストに新規行を追加します"""
    bl_idname = "bone.mapping_add"
    bl_label = "行を追加"
    bl_description = "マッピングリストに新しいリネーム項目を追加します"

    def execute(self, context):
        settings = context.scene.bone_batch_rename_settings
        item = settings.items.add()
        item.from_name = ""
        item.to_name = ""
        item.is_enabled = True
        settings.active_index = len(settings.items) - 1
        return {'FINISHED'}


class BONE_OT_remove_item(Operator):
    """選択中のマッピング行を削除します"""
    bl_idname = "bone.mapping_remove"
    bl_label = "行を削除"
    bl_description = "選択中のマッピング項目をリストから削除します"

    def execute(self, context):
        settings = context.scene.bone_batch_rename_settings
        if 0 <= settings.active_index < len(settings.items):
            settings.items.remove(settings.active_index)
            settings.active_index = max(0, settings.active_index - 1)
        return {'FINISHED'}


class BONE_OT_clear_items(Operator):
    """マッピングリストをすべて消去します"""
    bl_idname = "bone.mapping_clear"
    bl_label = "すべてクリア"
    bl_description = "マッピングリストのすべての項目を消去します"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.bone_batch_rename_settings
        settings.items.clear()
        settings.active_index = 0
        self.report({'INFO'}, "マッピングリストをクリアしました")
        return {'FINISHED'}


class BONE_OT_swap_from_to(Operator):
    """変更前と変更後の名前をすべて入れ替えます"""
    bl_idname = "bone.mapping_swap"
    bl_label = "変更前/変更後を入れ替え"
    bl_description = "リスト内の「変更前」と「変更後」の名前を反転します（逆変換用）"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.bone_batch_rename_settings
        for item in settings.items:
            item.from_name, item.to_name = item.to_name, item.from_name
        self.report({'INFO'}, "変更前と変更後を入れ替えました")
        return {'FINISHED'}


class BONE_OT_import_csv(Operator, ImportHelper):
    """CSVファイルからボーン名マッピングを読み込みます"""
    bl_idname = "bone.import_csv"
    bl_label = "CSVインポート"
    bl_description = "CSVファイルから変更前・変更後の対応リストを読み込みます"

    filename_ext = ".csv"
    filter_glob: StringProperty(
        default="*.csv;*.tsv;*.txt",
        options={'HIDDEN'},
        maxlen=255,
    )

    clear_existing: BoolProperty(
        name="既存リストをクリア",
        description="インポート前に現在のリストを消去します",
        default=True,
    )

    def execute(self, context):
        settings = context.scene.bone_batch_rename_settings
        filepath = self.filepath

        if not os.path.exists(filepath):
            self.report({'ERROR'}, "指定されたファイルが存在しません")
            return {'CANCELLED'}

        # エンコーディングの自動判定（UTF-8-SIG -> CP932）
        content = None
        for enc in ['utf-8-sig', 'utf-8', 'cp932', 'shift_jis']:
            try:
                with open(filepath, 'r', encoding=enc) as f:
                    content = f.readlines()
                break
            except (UnicodeDecodeError, LookupError):
                continue

        if content is None:
            self.report({'ERROR'}, "ファイルの文字コードを判別できませんでした（UTF-8 または Shift_JIS を推奨）")
            return {'CANCELLED'}

        if self.clear_existing:
            settings.items.clear()

        # 区切り文字の自動判定
        sample = "".join(content[:5])
        delimiter = ','
        if '\t' in sample and ',' not in sample:
            delimiter = '\t'

        reader = csv.reader(content, delimiter=delimiter)
        imported_count = 0

        for row_idx, row in enumerate(reader):
            if not row:
                continue
            # ヘッダースキップ判定
            if settings.csv_has_header and row_idx == 0:
                continue

            # コメント行スキップ
            if row[0].startswith('#'):
                continue

            from_val = row[0].strip() if len(row) > 0 else ""
            to_val = row[1].strip() if len(row) > 1 else ""

            if from_val:
                item = settings.items.add()
                item.from_name = from_val
                item.to_name = to_val
                item.is_enabled = True
                imported_count += 1

        self.report({'INFO'}, f"{imported_count} 件のマッピングをインポートしました")
        return {'FINISHED'}


class BONE_OT_export_csv(Operator, ExportHelper):
    """現在のマッピングリストをCSVファイルに保存します"""
    bl_idname = "bone.export_csv"
    bl_label = "CSVエクスポート"
    bl_description = "現在のマッピング設定をCSVファイルとして保存します"

    filename_ext = ".csv"
    filter_glob: StringProperty(
        default="*.csv",
        options={'HIDDEN'},
        maxlen=255,
    )

    include_header: BoolProperty(
        name="ヘッダー行を出力",
        description="1行目に 'Original,New' の見出しを出力します",
        default=True,
    )

    def execute(self, context):
        settings = context.scene.bone_batch_rename_settings
        filepath = self.filepath

        try:
            # Excelでも文字化けしないよう utf-8-sig で出力
            with open(filepath, 'w', encoding='utf-8-sig', newline='') as f:
                writer = csv.writer(f)
                if self.include_header:
                    writer.writerow(["Original", "New"])
                for item in settings.items:
                    writer.writerow([item.from_name, item.to_name])

            self.report({'INFO'}, f"CSVを保存しました: {os.path.basename(filepath)}")
            return {'FINISHED'}
        except Exception as e:
            self.report({'ERROR'}, f"CSV保存に失敗しました: {str(e)}")
            return {'CANCELLED'}


classes = (
    BONE_OT_batch_rename,
    BONE_OT_populate_bones,
    BONE_OT_add_item,
    BONE_OT_remove_item,
    BONE_OT_clear_items,
    BONE_OT_swap_from_to,
    BONE_OT_import_csv,
    BONE_OT_export_csv,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
