# -*- coding: utf-8 -*-
"""
Bone Batch Renamer - メインエントリポイント
Blender 4.2+ Extensions / アドオン登録用
"""

bl_info = {
    "name": "Bone Batch Renamer",
    "author": "Developer",
    "version": (1, 0, 0),
    "blender": (4, 2, 0),
    "location": "3D Viewport > Sidebar > Bone Renamer",
    "description": "アーマチュアのボーン名をUIマッピングリストやCSVから一括置換・リネームするツール",
    "category": "Rigging",
}

import sys
import importlib

# サブモジュールのインポート
from . import properties
from . import operators
from . import ui

# アドオン再読み込み時のモジュールリロード処理
if "properties" in locals():
    importlib.reload(properties)
if "operators" in locals():
    importlib.reload(operators)
if "ui" in locals():
    importlib.reload(ui)


def register():
    """エクステンションの登録"""
    properties.register()
    operators.register()
    ui.register()


def unregister():
    """エクステンションの登録解除"""
    ui.unregister()
    operators.unregister()
    properties.unregister()


if __name__ == "__main__":
    register()
