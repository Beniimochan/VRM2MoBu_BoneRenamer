# -*- coding: utf-8 -*-
"""
Bone Batch Renamer - プロパティ定義モジュール
ボーン名マッピングアイテムおよびアドオン全体の設定プロパティグループを定義します。
"""

import bpy
from bpy.props import (
    StringProperty,
    BoolProperty,
    EnumProperty,
    IntProperty,
    CollectionProperty,
    PointerProperty,
)
from bpy.types import PropertyGroup


def poll_armature_object(self, obj):
    """アーマチュアオブジェクトのみを選択可能にするフィルタ関数"""
    return obj.type == 'ARMATURE'


class BoneRenameItem(PropertyGroup):
    """リネームマッピングの1行分を表すデータクラス"""

    # 有効/無効フラグ
    is_enabled: BoolProperty(
        name="有効",
        description="このマッピングをリネーム処理に含めるかどうか",
        default=True,
    )

    # 変更前ボーン名
    from_name: StringProperty(
        name="変更前",
        description="現在のボーン名（置換対象）",
        default="",
    )

    # 変更後ボーン名
    to_name: StringProperty(
        name="変更後",
        description="新しいボーン名",
        default="",
    )


class BoneBatchRenameSettings(PropertyGroup):
    """エクステンション全体の設定およびリスト保持用プロパティグループ"""

    # 対象のアーマチュアオブジェクト
    target_armature: PointerProperty(
        name="対象アーマチュア",
        description="リネームを適用するアーマチュア。未指定時はアクティブオブジェクトを使用します",
        type=bpy.types.Object,
        poll=poll_armature_object,
    )

    # マッピングアイテム一覧
    items: CollectionProperty(
        type=BoneRenameItem,
        name="マッピングリスト",
    )

    # UIListのアクティブなインデックス
    active_index: IntProperty(
        name="選択インデックス",
        default=0,
    )

    # マッチ方式（完全一致 / 部分一致）
    match_mode: EnumProperty(
        name="マッチ方式",
        description="ボーン名の検索・置換方式",
        items=[
            ('EXACT', "完全一致", "ボーン名全体が変更前と一致する場合にリネームします"),
            ('PARTIAL', "部分置換", "ボーン名に含まれる変更前の文字列を置き換えます"),
        ],
        default='EXACT',
    )

    # 大文字・小文字を区別するかどうか
    case_sensitive: BoolProperty(
        name="大文字・小文字を区別",
        description="ボーン名の比較時に大文字・小文字を区別します",
        default=True,
    )

    # 頂点グループも同期リネームするか
    sync_vertex_groups: BoolProperty(
        name="頂点グループも同期",
        description="関連するメッシュオブジェクトの同名頂点グループ（Vertex Groups）も自動でリネームします",
        default=True,
    )

    # アニメーションアクションも同期リネームするか
    sync_animations: BoolProperty(
        name="アクション・アニメーションも同期",
        description="アニメーションアクション内のボーン名参照パスも同期して更新します",
        default=True,
    )

    # CSV読み込み時のヘッダースキップ設定
    csv_has_header: BoolProperty(
        name="CSVの1行目をスキップ",
        description="CSVファイルの1行目をヘッダー（見出し）として扱い、スキップします",
        default=False,
    )


classes = (
    BoneRenameItem,
    BoneBatchRenameSettings,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.bone_batch_rename_settings = PointerProperty(type=BoneBatchRenameSettings)


def unregister():
    if hasattr(bpy.types.Scene, "bone_batch_rename_settings"):
        del bpy.types.Scene.bone_batch_rename_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
